package sg.edu.rp.c346.id21018296.mymodules;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class AnswerActivity2 extends AppCompatActivity {
    TextView tvAnswer ;
    TextView tvAnswer1 ;
    TextView tvAnswer2;
    TextView tvAnswer3 ;
    TextView tvAnswer4 ;
    TextView tvAnswer5 ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_answer2);

        tvAnswer = findViewById(R.id.textView) ;
        tvAnswer1 = findViewById(R.id.textView);
        tvAnswer2 = findViewById(R.id.textView);
        tvAnswer3 = findViewById(R.id.textView);
        tvAnswer4 = findViewById(R.id.textView);
        tvAnswer5 = findViewById(R.id.textView);
        Intent intentReceived = getIntent();
        String value = intentReceived.getStringExtra("Module Code") ;
        String value1 = intentReceived.getStringExtra("Module Name") ;
        int value2 = intentReceived.getIntExtra("Academic Year" , 2020) ;
        int value3 = intentReceived.getIntExtra("Semester", 1) ;
        int value4 = intentReceived.getIntExtra("Module Credit", 4) ;
        String value5 = intentReceived.getStringExtra("Venue") ;

        tvAnswer.setText("Module Code : " + value);
        tvAnswer1.setText("Module Name : " + value1);
        tvAnswer2.setText("Academic Year : " + value2);
        tvAnswer3.setText("Semester : " + value3);
        tvAnswer4.setText("Module Credit: " + value4);
        tvAnswer5.setText("Venue : " + value5);


    }
}