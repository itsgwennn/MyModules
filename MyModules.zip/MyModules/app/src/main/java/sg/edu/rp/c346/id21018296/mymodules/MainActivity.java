package sg.edu.rp.c346.id21018296.mymodules;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView tvpassC346 ;
    TextView tvpassC349;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvpassC346 = findViewById(R.id.c346) ;
        tvpassC349 = findViewById(R.id.c349) ;

        tvpassC346.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AnswerActivity2.class) ;
                intent.putExtra("Module Code" , "C346");
                intent.putExtra("Module Name",  "Android Programming");
                intent.putExtra("Academic Year" , "2020") ;
                intent.putExtra("Semester" , "1") ;
                intent.putExtra("Module Credit" , "4") ;
                intent.putExtra("Venue" , "W66M") ;

                startActivity(intent);

            }
        });

        tvpassC349.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AnswerActivity3.class) ;
                intent.putExtra("Module Code" , "C349");
                intent.putExtra("Module Name",  "IPad Programming");
                intent.putExtra("Academic Year" , "2020") ;
                intent.putExtra("Semester" , "1") ;
                intent.putExtra("Module Credit" , "4") ;
                intent.putExtra("Venue" , "W66N") ;

            }
        });

    }

}